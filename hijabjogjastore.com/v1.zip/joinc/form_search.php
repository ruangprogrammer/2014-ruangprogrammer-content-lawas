<div class='srcBox' style='float:left;'>
<form method='POST' action='prosesCari'>
<input type='submit' class='ibutt' value='' title='Cari' />
<input name='cari' class='itext' type='text' placeholder='Search...' />
</form>
</div>