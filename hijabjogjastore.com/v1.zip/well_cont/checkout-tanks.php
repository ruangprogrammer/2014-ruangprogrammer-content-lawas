<div id="sb-site">
    <div class="overlay-background"></div>
    <div class="container marketing">
        <div class="row featurette">
            <div class="col-md-12">
                <h1>Terima Kasih!</h1>
                <p>Nomor Pesanan: <strong>927594</strong></p>
                <p>Silakan lakukan pembayaran dengan mentransfer (pemindahan dana) sejumlah
                    <strong>Rp. 116.000</strong> ke rekening kami sebagai berikut:</p>

                <p class="text-center">
                    <p class="text-center">Bank BCA</p>
                    <p class="text-center">
                        <img class="text-center" src="assets/images/icon-bca.jpg" alt="Bank BCA" />
                    </p>
                    <br>
                    <p class="text-center">Nomor Rekening: </p>
                    <h3 class="text-center">5055061880</h3>
                    <br>
                    <p class="text-center">Atas Nama</p>
                    <h3 class="text-center">Naniek Sumiati</h3>
                </p>
                <br/>
                <br/>
                <br/>
                <br/>
                <a href="http://www.pinkemma.com/checkout2/payment?o=poloqKZo" class="btn btn-warning">
                &lt;&lt; Pilih Pembayaran Lain</a>
            </div>
        </div>
    </div>
</div>