    <footer style="position: relative; margin-top:0px;">
        <style>
            .top {
                display: inline-block;
                width: 2.5em;
                height: 2.5em;
                border: 0.3em solid #f5f5f5;
                border-radius: 50%;
                margin-right: 0.3em;
                background-color: #f5f5f5;
            }
            
            .top:after {
                content: '';
                display: inline-block;
                margin-top: .6em;
                width: 1em;
                height: 1em;
                border-top: 0.3em solid #333;
                border-right: 0.3em solid #333;
                -moz-transform: rotate(-45deg);
                -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
            }
        </style>
        <p class="text-center" style="position: absolute; right: 1em; top:-1.25em">
            <a href="#" style="">
                <span class="top"></span>
                <br>
                <small style="margin-left: -.8em; color: #fff">ke atas</small>
            </a>

        </p>

        <p>&copy; 2016 HijabJogjaStore</p>

    </footer>
