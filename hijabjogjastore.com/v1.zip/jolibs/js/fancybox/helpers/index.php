<?php 
header('location: http://toyotabanten.com')
?>
